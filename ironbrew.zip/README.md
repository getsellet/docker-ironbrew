#IronBrew 2
VM-based Lua 5.1 obfuscation.