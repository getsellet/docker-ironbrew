namespace IronBrew2.Obfuscator.Macros
{
	public class Crash
	{
		
	}
}