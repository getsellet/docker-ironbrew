local x = 0
print(x == 0, x ~= 0)

local y = 1
print(x < y, x <= y, x > y, x >= y)